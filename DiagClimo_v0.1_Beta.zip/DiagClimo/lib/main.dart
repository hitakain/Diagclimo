import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;

void main() {
  runApp(const DiagClimoApp());
}

class DiagClimoApp extends StatelessWidget {
  const DiagClimoApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'DiagClimo',
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
      ),
      home: const HomePage(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<dynamic> codes = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final raw = await rootBundle.loadString('assets/data/codes.json');
    setState(() => codes = json.decode(raw));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('DiagClimo v0.1 Bêta ❄️')),
      body: codes.isEmpty
          ? const Center(child: CircularProgressIndicator())
          : ListView.builder(
              itemCount: codes.length,
              itemBuilder: (context, i) {
                final c = codes[i];
                return Card(
                  child: ListTile(
                    title: Text('${c['brand']} • ${c['code']} — ${c['title']}'),
                    subtitle: Text('${c['category']} • ${c['unit_type']}'),
                  ),
                );
              },
            ),
    );
  }
}